<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <header>
        <a href="criar_funcionario.php">Criar Funcionário</a>
        <a href="ver_funcionario.php">Ver Funcionário</a>
        <a href="editar_funcionario.php">Editar Funcionário</a>
        <a href="excluir_funcionario.php">Excluir Funcionário</a>
    </header>
    <form onsubmit="verFunc(event)" method="POST">
        <br><br>
        <label for="id_func">ID do funcionário que você deseja editar:</label>
        <input type="text" id="id_func">
        <br><br>
        <button type="submit">Enviar</button>
    </form>
    <div id="div_form" style="display:none">
        <h2 id="titulo"></h2>
    <form onsubmit="enviaFunc(event)" method="POST" >
        <br><br>
        <label for="name">Nome</label>
        <input type="text" id="name">
        <br><br>
        <label for="email">Email</label>
        <input type="text" id="email">
        <br><br>
        <label for="age">Idade</label>
        <input type="text" id="age">
        <br><br>
        <label for="designition">Cargo</label>
        <input type="text" id="designition">
        <br><br>
        <button type="submit">Enviar</button>
    </form>
    </div>
</body>

</html>

<script>
    function verFunc(event) {
       var id = document.getElementById('id_func').value;
       event.preventDefault();
       var myInit = {
            method: 'GET',
            mode: "no-cors",
            headers: {
                'Content-Type': 'application/json'
            }
        };
        fetch('http://localhost:50/aula-seguranca-digital/api/single_read.php/?id=' + id, myInit)
            .then(function(response) {
                return response.json();
            }).then(function(response) {
                if (response == "error") {
                    document.getElementById("titulo").innerHTML = 'Não foram encontrados os dados desse funcionário';
                } else {
                    console.log(response)
                    document.getElementById("div_form").style.display = 'block';
                    document.getElementById("titulo").innerHTML = 'Digite os novos dados do funcionário';
                    document.getElementById("name").value = response.name;
                    document.getElementById("email").value = response.email;
                    document.getElementById("age").value = response.age;
                    document.getElementById("designition").value = response.designation;
                }
            })
    }
</script>