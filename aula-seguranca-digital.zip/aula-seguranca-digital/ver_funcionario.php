<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <header>
        <a href="criar_funcionario.php">Criar Funcionário</a>
        <a href="ver_funcionario.php">Ver Funcionário</a>
        <a href="editar_funcionario.php">Editar Funcionário</a>
        <a href="excluir_funcionario.php">Excluir Funcionário</a>
    </header>
    <form onsubmit="verFunc(event)" method="POST">
        <br><br>
        <label for="id_func">ID do funcionário:</label>
        <input type="text" id="id_func">
        <br><br>
        <button type="submit">Enviar</button>
    </form>
    <div>
        <h2 id="titulo"></h2>
        <br>
        <p id="name"></p>
        <br>
        <p id="email"></p>
        <br>
        <p id="age"></p>
        <br>
        <p id="designation"></p>
        <br>
    </div>
</body>

</html>

<script>
    function verFunc(event) {
       var id = document.getElementById('id_func').value;
       event.preventDefault();
       var myInit = {
            method: 'GET',
            mode: "no-cors",
            headers: {
                'Content-Type': 'application/json'
            }
        };
        fetch('http://localhost:50/aula-seguranca-digital/api/single_read.php/?id=' + id, myInit)
            .then(function(response) {
                return response.json();
            }).then(function(response) {
                if (response == "error") {
                    document.getElementById("titulo").innerHTML = 'Não foram encontrados os dados desse funcionário';
                } else {
                    console.log(response)
                    document.getElementById("titulo").innerHTML = 'Dados do funcionário';
                    document.getElementById("name").innerHTML = response.name;
                    document.getElementById("email").innerHTML = response.email;
                    document.getElementById("age").innerHTML = response.age;
                    document.getElementById("designation").innerHTML = response.designation;
                }
            })
    }
</script>