<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <header>
        <a href="criar_funcionario.php">Criar Funcionário</a>
        <a href="ver_funcionario.php">Ver Funcionário</a>
        <a href="editar_funcionario.php">Editar Funcionário</a>
        <a href="excluir_funcionario.php">Excluir Funcionário</a>
    </header>
    <form onsubmit="enviaFunc(event)" method="POST">
        <br><br>
        <label for="name">Nome</label>
        <input type="text" id="name">
        <br><br>
        <label for="email">Email</label>
        <input type="text" id="email">
        <br><br>
        <label for="age">Idade</label>
        <input type="text" id="age">
        <br><br>
        <label for="designition">Cargo</label>
        <input type="text" id="designition">
        <br><br>
        <button type="submit">Enviar</button>
    </form>
</body>

</html>

<script>
    function enviaFunc(event) {
        const obj = {
            name: document.getElementById('name').value,
            email: document.getElementById('email').value,
            age: document.getElementById('age').value,
            designation: document.getElementById('designition').value
        };
        event.preventDefault();
        var myInit = {
            method: 'POST',
            mode: "no-cors",
            body: JSON.stringify(obj),
            headers: {
                'Content-Type': 'application/json'
            }
        };
        fetch('http://localhost:50/aula-seguranca-digital/api/create.php', myInit)
            .then(function(response) {
                return response.json();
            }).then(function(response) {
                if (response == 'success') {
                    alert('sucesso')
                        document.getElementById('name').value = '',
                        document.getElementById('email').value = '',
                        document.getElementById('age').value = '',
                        document.getElementById('designition').value = ''
                } else {
                    alert('Erro ao cadastrar funcionário')
                }
            })
    }
</script>