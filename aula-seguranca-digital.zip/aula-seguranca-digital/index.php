<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <header>
        <a href="criar_funcionario.php">Criar Funcionário</a>
        <a href="ver_funcionario.php">Ver Funcionário</a>
        <a href="editar_funcionario.php">Editar Funcionário</a>
        <a href="excluir_funcionario.php">Excluir Funcionário</a>
    </header>
    <h2>Listagem dos empregados:</h2>
    <table>
        <thead>
            <th>Id</th>
            <th>Nome</th>
            <th>Email</th>
            <th>Idade</th>
            <th>Cargo</th>
            <th>Criado em</th>
        </thead>
        <tbody>
            <ul>
                <?php
                $url = 'http://localhost:50/aula-seguranca-digital/api/read.php';
                $curl = curl_init($url);
                curl_setopt($curl, CURLOPT_RETURNTRANSFER, True);
                $return = curl_exec($curl);
                curl_close($curl);
                $emps = json_decode($return, true);
                for ($i = 0; $i < 10; $i++) {
                    echo '<tr>' . '<td>' . $emps['body'][$i]['id'] . '</td>' . 
                                  '<td>' . $emps['body'][$i]['name'] . '</td>' . 
                                  '<td>' . $emps['body'][$i]['email'] . '</td>' .
                                  '<td>' . $emps['body'][$i]['age'] . '</td>' .
                                  '<td>' . $emps['body'][$i]['designation'] . '</td>' .
                                  '<td>' . $emps['body'][$i]['created'] . '</td>' .
                          '</tr>';
                }
                ?>
            </ul>
        </tbody>
    </table>
</body>

</html>